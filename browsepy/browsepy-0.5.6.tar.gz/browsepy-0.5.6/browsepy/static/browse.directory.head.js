(function(){
  if(document.documentElement && document.querySelectorAll && document.addEventListener){
    document.documentElement.className += ' autosubmit-support';
  }
}());
