.. _test-utils:

Test Utility Module
===================

Convenience functions for unit testing.

.. automodule:: browsepy.tests.utils
  :show-inheritance:
  :members:
  :inherited-members:
