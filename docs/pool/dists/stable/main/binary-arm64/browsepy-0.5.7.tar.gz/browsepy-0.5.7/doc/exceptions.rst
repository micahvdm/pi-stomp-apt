.. _exceptions:

Exceptions Module
=================

Exceptions raised by browsepy classes.

.. automodule:: browsepy.exceptions
  :show-inheritance:
  :members:
  :inherited-members:
